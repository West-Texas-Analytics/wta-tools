"""Write the 3D viewer as one self-contained HTML file.

Everything is inlined (three.js r128 and OrbitControls, MIT licensed, in
viewer/vendor/), so the page works offline and makes no network calls: it can
be opened from disk at a district or served by the shell on 127.0.0.1.
"""

from __future__ import annotations

import html
import json
from importlib.resources import files

_PKG = files("wta_stacks") / "viewer"


def _script_safe(text: str) -> str:
    """Keep inlined text from closing its <script> element early."""
    return text.replace("</script", "<\\/script").replace("</SCRIPT", "<\\/SCRIPT")


def render_html(view: dict) -> str:
    template = (_PKG / "template.html").read_text(encoding="utf-8")
    three = (_PKG / "vendor" / "three.min.js").read_text(encoding="utf-8")
    orbit = (_PKG / "vendor" / "OrbitControls.js").read_text(encoding="utf-8")
    data = json.dumps(view, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
    return (template
            .replace("__TITLE__", html.escape(view["title"]))
            .replace("/*__THREE__*/", _script_safe(three))
            .replace("/*__ORBIT__*/", _script_safe(orbit))
            .replace("__DATA__", data))
