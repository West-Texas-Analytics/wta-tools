"""A rule-based guess at why rows share a shape. It sorts the review; it isn't a finding."""

from __future__ import annotations

import re

# key -> label, kind ("bad" = probable error, "ok" = often valid), colour in the viewer.
CAUSES: dict[str, dict[str, str]] = {
    "blank": {"label": "Blank owner and legal", "kind": "bad", "color": "#7A5C99"},
    "dump": {"label": "Catch-all shape (20+ rows)", "kind": "bad", "color": "#8E2F22"},
    "dup": {"label": "Duplicate account", "kind": "bad", "color": "#C8553D"},
    "split": {"label": "Different legals on one shape", "kind": "bad", "color": "#D98A3D"},
    "mineral": {"label": "Mineral interests", "kind": "ok", "color": "#2E6F8E"},
    "bpp": {"label": "Business personal property", "kind": "ok", "color": "#5B7F3A"},
    "mh": {"label": "Mobile home on land", "kind": "ok", "color": "#6E8B3D"},
    "utility": {"label": "Utility or pipeline", "kind": "ok", "color": "#5D6B78"},
    "undiv": {"label": "Same legal, different owners", "kind": "ok", "color": "#4F7A8C"},
}

DUMP_ROWS = 20

# Texas PTD state codes: first letter -> cause, for stacks where a row's code says why it shares land.
_STATE_CODE = {"G": "mineral", "L": "bpp", "M": "mh", "J": "utility"}


def _norm(s) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(s or "").upper())


def likely_cause(rows: list[dict]) -> str:
    """`rows` hold role keys: owner, legal and (optionally) land_use."""
    if any(not r.get("owner") and not r.get("legal") for r in rows):
        return "blank"
    if len(rows) >= DUMP_ROWS:
        return "dump"
    for r in rows:
        code = _norm(r.get("land_use"))[:1]
        if code in _STATE_CODE:
            return _STATE_CODE[code]
    owners = {_norm(r.get("owner")) for r in rows}
    legals = {_norm(r.get("legal")) for r in rows}
    if len(legals) == 1:
        return "dup" if len(owners) == 1 else "undiv"
    return "split"
