"""Parcel stacks: find rows that share the same polygon and show them in 3D.

The logic here is plain Python with no UI, so the shell plugin screen (next
step) and the `wta-stacks` command line both sit on top of it.
"""

from .build import Result, build, stacks_csv
from .detect import find_stacks, shape_key
from .load import Layer, read_layer
from .viewer import render_html

__all__ = ["Layer", "Result", "build", "find_stacks", "read_layer", "render_html", "shape_key", "stacks_csv"]
