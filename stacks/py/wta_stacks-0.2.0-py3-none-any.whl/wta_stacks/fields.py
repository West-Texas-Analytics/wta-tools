"""Which columns of a parcel layer mean what.

CAD and StratMap files name the same thing many ways (PROP_ID, PROPID, ACCOUNT ...).
`map_fields` picks a column for each role by name, case-insensitively, and the
caller can override any role by hand.
"""

from __future__ import annotations

# Role -> candidate column names, most likely first. Compared case-insensitively.
# STAT_LAND_ is STAT_LAND_USE cut to the 10 characters a shapefile .dbf allows.
CANDIDATES: dict[str, tuple[str, ...]] = {
    "account": ("PROP_ID", "PROPID", "PROP_ID_TEXT", "ACCOUNT", "ACCOUNT_NUM", "ACCT", "ACCT_NUM", "PID",
                "PARCEL_ID", "PARCELID"),
    "geo_id": ("GEO_ID", "GEOID", "QUICKREF", "QUICK_REF", "MAP_ID", "MAPID"),
    "owner": ("OWNER_NAME", "OWNERNAME", "OWNER", "FILE_AS_NAME", "OWNER1", "NAME"),
    "legal": ("LEGAL_DESC", "LEGALDESC", "LEGAL_DESCRIPTION", "LEGAL", "LGL_DESC"),
    "legal_acres": ("LEGAL_AREA", "LEGAL_ACRE", "LEGAL_ACRES", "LGL_ACRES", "ACRES", "LAND_ACRES", "DEED_ACRES"),
    "land_use": ("STAT_LAND_USE", "STAT_LAND_", "STATE_CD", "STATE_CODE", "PTD_CODE", "SPTB_CODE", "LAND_USE", "PROP_TYPE"),
    "market_value": ("MKT_VALUE", "MARKET_VALUE", "MARKET", "MKT_VAL", "APPRAISED_VALUE", "APPR_VALUE"),
    "situs": ("SITUS_ADDR", "SITUS", "SITUS_ADDRESS", "SITUS_FULL"),
}

# Display names used in the viewer's row table, in column order.
LABELS: dict[str, str] = {
    "account": "Account",
    "geo_id": "Geo ID",
    "owner": "Owner",
    "legal": "Legal",
    "legal_acres": "Legal acres",
    "land_use": "Land use",
    "market_value": "Market value",
    "situs": "Situs",
}

NUMERIC_ROLES = {"legal_acres", "market_value"}


def map_fields(columns: list[str], overrides: dict[str, str] | None = None) -> dict[str, str]:
    """Return {role: column} for every role found in `columns`.

    `overrides` wins over guessing. An override naming a column that isn't in the
    layer raises ValueError, so a typo fails loudly instead of silently dropping a field.
    """
    by_upper = {c.upper(): c for c in columns}
    found: dict[str, str] = {}
    for role, names in CANDIDATES.items():
        for name in names:
            if name in by_upper:
                found[role] = by_upper[name]
                break
    for role, column in (overrides or {}).items():
        if role not in CANDIDATES:
            raise ValueError(f"Unknown field role '{role}'. Roles: {', '.join(CANDIDATES)}")
        if column.upper() not in by_upper:
            raise ValueError(f"Column '{column}' (for {role}) is not in the layer. Columns: {', '.join(columns)}")
        found[role] = by_upper[column.upper()]
    return found
