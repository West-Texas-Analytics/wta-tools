"""The bridge the tools website calls when wta-stacks runs in the browser (Pyodide).

Everything crosses as JSON text or plain bytes, so the page's JavaScript needs no
knowledge of Python objects. Errors meant for the visitor come back as
{"error": "..."} instead of a Python traceback.
"""

from __future__ import annotations

import json

from .build import build_steps, stacks_csv
from .crs import DEFAULT_DETECT, KNOWN, ZONES, resolve_crs
from .fields import CANDIDATES, LABELS, map_fields
from .osm import OVERPASS, context_from_osm, overpass_query
from .readers import open_files as _open_files

_sources: list = []     # what open_files found, for open_layer(i)
_layers: dict = {}      # i -> Layer, read once


def _bytes(b) -> bytes:
    return bytes(b.to_py() if hasattr(b, "to_py") else b)


def _json(v) -> str:
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def boot_info() -> str:
    return _json({"KNOWN": KNOWN, "ZONES": ZONES, "DEFAULT_DETECT": DEFAULT_DETECT, "LABELS": LABELS,
                  "CANDIDATES": {k: list(v) for k, v in CANDIDATES.items()}, "OVERPASS": OVERPASS})


def open_files(names, datas) -> str:
    """names: file names; datas: their bytes. -> [{name, kind}] or {error}."""
    global _sources
    try:
        _sources = _open_files([(str(n), _bytes(d)) for n, d in zip(names, datas)])
    except ValueError as e:
        return _json({"error": str(e)})
    _layers.clear()
    return _json([{"name": s.name, "kind": s.kind} for s in _sources])


def open_layer(i: int) -> str:
    """-> {name, columns, records, shapes (1 = has a polygon, 0 = none), crs_text} or {error}."""
    try:
        if i not in _layers:
            _layers[i] = _sources[i].open()
        L = _layers[i]
    except ValueError as e:
        return _json({"error": str(e)})
    return _json({"name": L.name, "columns": L.columns, "records": L.records,
                  "shapes": [0 if g is None else 1 for g in L.geoms], "crs_text": L.crs_text})


def guess(columns: str) -> str:
    """Which column is which role, guessed from the names: {role: column}."""
    return _json(map_fields(json.loads(columns)))


def resolve(text) -> str:
    try:
        return _json({"crs": resolve_crs(text)})
    except ValueError as e:
        return _json({"error": str(e)})


def build_json(i: int, opts: str):
    """A generator: yields progress lines, returns {view, stackRows} (or {error}) as JSON text."""
    o = json.loads(opts)
    try:
        steps = build_steps(_layers[i], title=o.get("title"), source=o.get("source"), roles=o.get("roles"),
                            color_columns=o.get("extra"), detect_crs=o.get("detect") or DEFAULT_DETECT,
                            source_crs=o.get("crs"))
        while True:
            try:
                yield next(steps)
            except StopIteration as done:
                res = done.value
                break
    except ValueError as e:
        return _json({"error": str(e)})
    return _json({"view": res.view, "stackRows": res.stack_rows})


def csv_text(stack_rows: str) -> str:
    return stacks_csv(json.loads(stack_rows))


def overpass(bbox: str) -> str:
    return overpass_query(json.loads(bbox))


def context(osm: str, view: str) -> str:
    return _json(context_from_osm(json.loads(osm), json.loads(view)))
