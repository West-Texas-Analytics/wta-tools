"""Turn a parcel layer into the data the 3D viewer draws, plus a flat stack list for CSV.

The tools website runs this same code in the visitor's browser (Pyodide), through
`web.py`; the `wta-stacks` command line runs it on the desktop.
"""

from __future__ import annotations

import csv
import io
import math
import re
from collections.abc import Callable, Generator
from dataclasses import dataclass
from datetime import date

import numpy as np
import shapely
from pyproj import CRS, Transformer

from .causes import CAUSES, likely_cause
from .detect import DEFAULT_DETECT_CRS, explode, find_stacks, to_feet
from .fields import LABELS, NUMERIC_ROLES, map_fields
from .load import Layer

SCENE_FT = 10.0          # one viewer unit = 10 ft
GROUND_SIMPLIFY_FT = 4.0  # the ground layer is simplified this much; stacks keep full detail
MAX_CATEGORIES = 10       # a text field with more values than this can't be a colour category
COUNTY_MILES = 600        # parcels spread wider than this mean the CRS doesn't match the coordinates


@dataclass
class Result:
    view: dict           # JSON-ready data for the viewer
    stack_rows: list[dict]  # one row per stacked feature, for CSV export


def _natural(v) -> list:
    """Sort key that puts account 9 before 10."""
    return [(0, int(t), "") if t.isdigit() else (1, 0, t) for t in re.split(r"(\d+)", str(v)) if t]


def _scene_rings(geoms: list, cx: float, cy: float, simplify_ft: float = 0.0) -> list[list]:
    """Each shape -> [[ring, ...] per part] in scene units (10 ft, centred on cx, cy, 0.1 precision),
    exterior rings counter-clockwise and holes clockwise, without the closing point."""
    if simplify_ft:
        geoms = list(shapely.simplify(np.array(geoms, dtype=object), simplify_ft, preserve_topology=True))
    out = []
    for parts in explode(geoms):
        shape = []
        for rings in parts:
            part = []
            for k, r in enumerate(rings):
                x, y = r[:-1, 0], r[:-1, 1]
                ccw = float(np.dot(x, np.roll(y, -1)) - np.dot(np.roll(x, -1), y)) > 0
                pts = np.round(np.column_stack([(x - cx) / SCENE_FT, (y - cy) / SCENE_FT]), 1).tolist()
                part.append(pts if ccw == (k == 0) else pts[::-1])
            shape.append(part)
        out.append(shape)
    return out


def _color_fields(stacked: list[dict], roles: dict[str, str], extra: list[str]) -> list[dict]:
    """Fields offered under "Color stacks by", beyond the built-in ones."""
    specs = []
    wanted = [(LABELS[r], r in NUMERIC_ROLES) for r in ("land_use", "market_value", "legal_acres") if r in roles]
    wanted += [(c, None) for c in extra]
    for label, numeric in wanted:
        vals = [r.get(label) for r in stacked if r.get(label) not in (None, "")]
        if not vals:
            continue
        if numeric is None:
            numeric = all(isinstance(v, (int, float)) for v in vals)
        if numeric:
            pos = [v for v in vals if isinstance(v, (int, float)) and v > 0]
            if pos:
                specs.append({"key": label, "type": "num", "min": min(pos), "max": max(pos)})
        else:
            counts: dict[str, int] = {}
            for v in vals:
                counts[str(v)] = counts.get(str(v), 0) + 1
            top = sorted(counts, key=lambda k: -counts[k])[:MAX_CATEGORIES]
            specs.append({"key": label, "type": "cat", "values": top, "other": len(counts) > len(top)})
    return specs


def _bbox_ll(detect_crs: str, minx: float, miny: float, maxx: float, maxy: float) -> list[float]:
    """[south, west, north, east] in degrees around the parcels, padded 0.01 degree."""
    tr = Transformer.from_crs(detect_crs, "EPSG:4326", always_xy=True)
    lon, lat = tr.transform([minx, minx, maxx, maxx], [miny, maxy, miny, maxy])
    pad = 0.01
    return [round(min(lat) - pad, 4), round(min(lon) - pad, 4), round(max(lat) + pad, 4), round(max(lon) + pad, 4)]


def _crs_name(code: str) -> str:
    from .crs import KNOWN
    return KNOWN[code]["name"] if code in KNOWN else CRS.from_user_input(code).name


def resolve_roles(layer: Layer, overrides: dict[str, str] | None = None,
                  roles: dict[str, str] | None = None) -> dict[str, str]:
    """`roles` (role -> column, exactly as picked on the page) wins; otherwise guess and apply `overrides`."""
    if roles is None:
        return map_fields(layer.columns, overrides)
    out = {}
    for role, col in roles.items():
        if not col:
            continue
        if role not in LABELS:
            raise ValueError(f"Unknown field role '{role}'. Roles: {', '.join(LABELS)}")
        if col not in layer.columns:
            raise ValueError(f"Column '{col}' (for {role}) is not in the layer.")
        out[role] = col
    return out


def build_steps(layer: Layer, *, title: str | None = None, source: str | None = None,
                overrides: dict[str, str] | None = None, roles: dict[str, str] | None = None,
                color_columns: list[str] | None = None, detect_crs: str = DEFAULT_DETECT_CRS,
                source_crs: str | None = None, likely_causes: bool = False,
                ) -> Generator[str, None, Result]:
    """`build`, one step at a time: yields a progress line before each slow step, returns the Result.

    The browser page shows each line and lets the screen repaint between steps.
    `source_crs` overrides the layer's own CRS (an EPSG code, WKT or PROJ string).
    `likely_causes` adds the rule-based guess at why rows share a shape (desktop
    page only; the website page doesn't presume a cause).
    """
    roles = resolve_roles(layer, overrides, roles)
    extra = [c for c in (color_columns or []) if c not in roles.values()]
    for c in extra:
        if c not in layer.columns:
            raise ValueError(f"Column '{c}' is not in the layer. Columns: {', '.join(layer.columns)}")
    src = CRS.from_user_input(source_crs) if source_crs else layer.crs
    if src is None:
        raise ValueError("This file has no coordinate system (a shapefile without its .prj?). "
                         "Pick the right one and build again.")

    yield f"Projecting {len(layer.geoms):,} parcels to {_crs_name(detect_crs)}…"
    geoms_ft = to_feet(layer.geoms, src, detect_crs)
    present = [g for g in geoms_ft if g is not None]
    if not present:
        raise ValueError("The layer has no usable polygons.")
    coords = shapely.get_coordinates(np.array(present, dtype=object))
    bad = int((~np.isfinite(coords).all(axis=1)).sum())
    if bad:
        raise ValueError(f"{bad:,} points couldn't be placed. The file's coordinate system ({src.name}) probably "
                         "doesn't match its coordinates; pick the right one and build again.")
    minx, miny = coords.min(axis=0)
    maxx, maxy = coords.max(axis=0)
    if maxx - minx > 5280 * COUNTY_MILES or maxy - miny > 5280 * COUNTY_MILES:
        raise ValueError(f"The parcels spread over {round((maxx - minx) / 5280):,} miles, which is more than a "
                         f"county. The coordinate system ({src.name}) probably doesn't match the coordinates; "
                         "pick the right one and build again.")

    yield "Comparing shapes…"
    stacks = find_stacks(geoms_ft, layer.wkb)
    cx, cy = float(minx + maxx) / 2, float(miny + maxy) / 2

    def table_row(i: int) -> dict:
        rec = layer.records[i]
        row = {LABELS[role]: rec.get(col) for role, col in roles.items()}
        for c in extra:
            row[c] = rec.get(c)
        if row.get("Account") is None:
            row["Account"] = f"(row {i + 1})"
        return row

    out_stacks, stack_rows = [], []
    for n, st in enumerate(stacks, start=1):
        g = geoms_ft[st.rows[0]]
        order = sorted(((i, table_row(i)) for i in st.rows), key=lambda o: _natural(o[1]["Account"]))
        rows = [r for _, r in order]
        acres = round(g.area / 43560, 2)
        c = g.centroid
        s = {"polys": _scene_rings([g], cx, cy)[0], "acres": acres, "exact": st.exact,
             "cx": round((c.x - cx) / SCENE_FT, 1), "cy": round((c.y - cy) / SCENE_FT, 1),
             "rows": rows, "recs": [layer.records[i] for i, _ in order]}
        cause = None
        if likely_causes:
            cause = likely_cause([{role: layer.records[i].get(col) for role, col in roles.items()} for i in st.rows])
            s["cause"] = cause
        out_stacks.append(s)
        for r in rows:
            row = {"stack": n, "rows_in_stack": len(rows)}
            if likely_causes:
                row["likely_cause"] = CAUSES[cause]["label"]
            stack_rows.append({**row, "exact_match": "yes" if st.exact else "no", "shape_acres": acres, **r})

    yield "Drawing the ground layer…"
    ground = _scene_rings(present, cx, cy, GROUND_SIMPLIFY_FT)
    stacked = [r for s in out_stacks for r in s["rows"]]
    fields = [LABELS[r] for r in LABELS if r in roles] + extra
    if "Account" not in fields:
        fields.insert(0, "Account")
    view = {
        "title": title or f"{layer.name} parcel stacks",
        "source": source or f"layer {layer.name}",
        "built": date.today().isoformat(),
        "parcels": len(layer.geoms),
        "skipped": layer.skipped,
        "detect_crs": detect_crs,
        "missing_roles": [LABELS[r] for r in LABELS if r not in roles],
        "empty_roles": [LABELS[r] for r, col in roles.items()
                        if all(rec.get(col) in (None, "", 0) for rec in layer.records)],
        "fields": fields,
        "columns": list(layer.columns),
        "color_fields": _color_fields(stacked, roles, extra),
        "extent_ft": [round(float(maxx - minx)), round(float(maxy - miny))],
        "origin_ft": [cx, cy],
        "bbox_ll": _bbox_ll(detect_crs, minx, miny, maxx, maxy),
        "ground": ground,
        "stacks": out_stacks,
    }
    if likely_causes:
        view["causes"] = CAUSES
    return Result(view=view, stack_rows=stack_rows)


def build(layer: Layer, *, on_progress: Callable[[str], None] | None = None, **kw) -> Result:
    """Find the stacks and build the viewer data. Keyword arguments as for `build_steps`."""
    steps = build_steps(layer, **kw)
    while True:
        try:
            line = next(steps)
        except StopIteration as done:
            return done.value
        if on_progress:
            on_progress(line)


def _cell(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and math.isfinite(v) and v.is_integer():
        return str(int(v))
    return str(v)


def stacks_csv(stack_rows: list[dict]) -> str:
    if not stack_rows:
        return "stack,rows_in_stack,exact_match,shape_acres\n"
    cols: list[str] = []
    for r in stack_rows:
        for k in r:
            if k not in cols:
                cols.append(k)
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(cols)
    for r in stack_rows:
        w.writerow([_cell(r.get(c)) for c in cols])
    return buf.getvalue()
