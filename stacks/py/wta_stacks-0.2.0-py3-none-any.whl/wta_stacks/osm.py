"""Roads and towns from OpenStreetMap, placed in the viewer's scene.

The page asks the Overpass API itself (only the map area's corners are sent);
this module writes the question and turns the answer into scene coordinates.
"""

from __future__ import annotations

import math

from pyproj import Transformer

from .build import SCENE_FT

OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.private.coffee/api/interpreter"]
ROAD_CLASS = {
    "motorway": "major", "trunk": "major", "primary": "major",
    "motorway_link": "major", "trunk_link": "major", "primary_link": "major",
    "secondary": "fm", "secondary_link": "fm", "tertiary": "fm",
    "unclassified": "local", "residential": "local",
}


def overpass_query(bbox: list[float]) -> str:
    """bbox: [south, west, north, east] in degrees."""
    box = ",".join(str(v) for v in bbox)
    return (f'[out:json][timeout:90];(way["highway"~"^({"|".join(ROAD_CLASS)})$"]({box});'
            f'node["place"~"^(city|town|village|hamlet)$"]({box}););out geom;')


def _finite(v) -> bool:
    return isinstance(v, (int, float)) and math.isfinite(v)


def context_from_osm(osm: dict, view: dict) -> dict:
    """Overpass JSON -> {roads: [{cls, label, pts}], towns: [{name, kind, x, y}], source}."""
    tr = Transformer.from_crs("EPSG:4326", view["detect_crs"], always_xy=True)
    ox, oy = view["origin_ft"]

    def sc(lon, lat):
        x, y = tr.transform(lon, lat)
        return [round((x - ox) / SCENE_FT, 1), round((y - oy) / SCENE_FT, 1)]

    roads, towns = [], []
    for el in (osm or {}).get("elements") or []:
        t = el.get("tags") or {}
        if el.get("type") == "way" and isinstance(el.get("geometry"), list) and t.get("highway") in ROAD_CLASS:
            pts = [sc(g["lon"], g["lat"]) for g in el["geometry"]
                   if isinstance(g, dict) and _finite(g.get("lat")) and _finite(g.get("lon"))]
            if len(pts) >= 2:
                label = (t.get("ref") or t.get("name") or "").split(";")[0].strip()
                roads.append({"cls": ROAD_CLASS[t["highway"]], "label": label, "pts": pts})
        elif el.get("type") == "node" and t.get("name") and _finite(el.get("lat")):
            x, y = sc(el["lon"], el["lat"])
            towns.append({"name": t["name"], "kind": t.get("place"), "x": x, "y": y})
    return {"roads": roads, "towns": towns, "source": "OpenStreetMap"}
