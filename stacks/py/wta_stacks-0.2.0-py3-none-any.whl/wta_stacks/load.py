"""Read a parcel layer from any file GDAL can open (shapefile or zipped shapefile,
GeoPackage, file geodatabase, GeoJSON) into plain Python objects."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import shapely
from pyproj import CRS

# pyogrio (GDAL) is imported inside the functions that use it: the browser build
# reads files with readers.py instead and has no GDAL.


@dataclass
class Layer:
    path: str
    name: str
    crs: CRS | None        # None when the file has none (or one pyproj can't read; see crs_text)
    columns: list[str]
    geoms: list            # shapely geometries, 2D, in the layer's own CRS (None where missing or empty)
    wkb: list              # the raw geometry bytes as stored, for the "exact match" test
    records: list[dict]    # one dict of column -> plain Python value per feature
    skipped: int = 0       # features with no usable polygon
    layers_in_file: list[str] = field(default_factory=list)
    crs_text: str | None = None   # what the file said about its CRS, as written


def _plain(v):
    """numpy scalars and NaN -> plain Python values / None, strings trimmed."""
    if v is None:
        return None
    if isinstance(v, (np.floating, float)):
        if np.isnan(v):
            return None
        v = float(v)
        return int(v) if v.is_integer() and abs(v) < 2 ** 53 else v  # 1200.0 -> 1200, as the browser shows it
    if isinstance(v, np.integer):
        return int(v)
    if isinstance(v, (bytes, bytearray)):
        return None
    if isinstance(v, np.datetime64):
        return None if np.isnat(v) else str(v)[:10]
    s = str(v).strip()
    return s or None


def list_polygon_layers(path: str | Path) -> list[str]:
    import pyogrio
    # GeoJSON layers report "Unknown" until read, so they count too; non-polygon features are skipped later.
    return [str(n) for n, g in pyogrio.list_layers(str(path)) if g and ("Polygon" in str(g) or str(g) == "Unknown")]


def read_layer(path: str | Path, layer: str | None = None, source_crs: str | None = None) -> Layer:
    """Read one polygon layer.

    `layer` picks a layer when the file has several; by default the only polygon
    layer is used, and a file with more than one is refused with their names.
    `source_crs` is for files with no projection info (a shapefile missing its .prj).
    """
    import pyogrio

    path = str(path)
    polys = list_polygon_layers(path)
    if layer is None:
        if not polys:
            raise ValueError(f"No polygon layer found in {path}.")
        if len(polys) > 1:
            raise ValueError(f"{path} has several polygon layers; pick one with --layer: {', '.join(polys)}")
        layer = polys[0]

    meta, _fids, geom_wkb, field_data = pyogrio.raw.read(path, layer=layer)
    crs_text = meta.get("crs") or source_crs
    if not crs_text:
        raise ValueError(
            f"{path} has no coordinate system (a shapefile without its .prj?). "
            "Pass the right one with --source-crs, e.g. --source-crs EPSG:2277."
        )
    columns = [str(c) for c in meta["fields"]]
    geoms, raw = [], []
    skipped = 0
    for b in geom_wkb:
        g = shapely.from_wkb(b) if b is not None else None
        if g is not None:
            g = shapely.force_2d(g)
            if g.is_empty or g.geom_type not in ("Polygon", "MultiPolygon"):
                g = None
        if g is None:
            skipped += 1
        geoms.append(g)
        raw.append(b)
    records = [{c: _plain(field_data[j][i]) for j, c in enumerate(columns)} for i in range(len(geoms))]
    return Layer(path=path, name=layer, crs=CRS.from_user_input(crs_text), columns=columns, geoms=geoms,
                 wkb=raw, records=records, skipped=skipped, layers_in_file=polys,
                 crs_text=crs_text)
