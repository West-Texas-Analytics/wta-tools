"""Read parcel files without GDAL: zipped shapefiles, loose .shp/.dbf/.prj/.cpg,
GeoPackage and GeoJSON, from bytes in memory.

This is the reader the tools website uses, where wta-stacks runs in the visitor's
browser (Pyodide) and pyogrio/GDAL isn't available. It needs only the standard
library, shapely and pyproj, and returns the same `Layer` as `load.read_layer`,
so everything after reading (`build`) is shared. File geodatabases still need the
desktop reader.
"""

from __future__ import annotations

import io
import json
import math
import os
import re
import sqlite3
import struct
import tempfile
import zipfile
from dataclasses import dataclass
from typing import Callable

import numpy as np
from pyproj import CRS
from shapely.geometry import MultiPolygon, Polygon

from .load import Layer

FGDB_HINT = ("In ArcGIS Pro, export the parcel layer to a shapefile or GeoPackage, "
             "or use the desktop tool.")
_WANTED = re.compile(r"\.(shp|dbf|prj|cpg|gpkg|geojson|json)$", re.I)
_SHP_POLY = {5, 15, 25}


@dataclass
class Source:
    """One polygon layer found in the picked files. `open()` reads it."""
    name: str
    kind: str                       # "Shapefile", "GeoPackage" or "GeoJSON"
    open: Callable[[], Layer]


def _ext(name: str) -> str:
    m = re.search(r"\.([^./\\]+)$", name)
    return m.group(1).lower() if m else ""


def _stem(name: str) -> str:
    return re.sub(r"\.[^.]+$", "", re.sub(r"^.*[/\\]", "", name))


def plain_number(v: float | int):
    """1200.0 -> 1200, so numbers read the same here as in the browser's JavaScript."""
    if isinstance(v, float) and v.is_integer() and abs(v) < 2 ** 53:
        return int(v)
    return v


def _plain_str(s: str):
    s = s.strip()
    return s or None


# ------------------------------------------------------------------ rings -> polygons
# A ring is an (n, 2) numpy array of x, y, without the closing point.
def _signed_area(r) -> float:
    r = np.asarray(r, dtype=float)
    x, y = r[:, 0], r[:, 1]
    # shoelace: sum of x[i] * y[i+1] - x[i+1] * y[i], wrapping around
    return float(x[:-1] @ y[1:] - x[1:] @ y[:-1] + x[-1] * y[0] - x[0] * y[-1]) / 2


def _in_ring(pt, r) -> bool:
    c = False
    x, y = pt[0], pt[1]
    j = len(r) - 1
    for i in range(len(r)):
        a, b = r[i], r[j]
        if (a[1] > y) != (b[1] > y) and x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]:
            c = not c
        j = i
    return c


def _open_ring(pts):
    """Drop the closing point a ring repeats."""
    if len(pts) > 1 and pts[0][0] == pts[-1][0] and pts[0][1] == pts[-1][1]:
        return pts[:-1]
    return pts


def _organize(rings: list) -> list:
    """Shapefile rings -> [[outer, hole, ...], ...]: clockwise rings are outer rings,
    counter-clockwise ones are holes in the smallest outer ring around them."""
    outer, holes = [], []
    for r in rings:
        if len(r) < 3:
            continue
        a = _signed_area(r)
        if a < 0:
            outer.append((r, -a))
        elif a > 0:
            holes.append(r)
    if not outer:
        return [[h] for h in holes]
    polys = [{"rings": [r], "a": a, "ring": r} for r, a in outer]
    for h in holes:
        best = None
        for p in polys:
            if (best is None or p["a"] < best["a"]) and _in_ring(h[0], p["ring"]):
                best = p
        if best:
            best["rings"].append(h)
        else:
            polys.append({"rings": [h], "a": abs(_signed_area(h)), "ring": h})
    return [p["rings"] for p in polys]


def _to_geom(polys: list):
    """[[outer, hole, ...], ...] -> a shapely (Multi)Polygon, or None when nothing usable is left."""
    parts = [Polygon(p[0], [h for h in p[1:] if len(h) >= 3]) for p in polys if p and len(p[0]) >= 3]
    parts = [p for p in parts if not p.is_empty]
    if not parts:
        return None
    return parts[0] if len(parts) == 1 else MultiPolygon(parts)


# ------------------------------------------------------------------ shapefile
def _parse_shp(b: bytes) -> list:
    """Each record -> (polys, raw bytes) or None."""
    if len(b) < 100 or struct.unpack_from(">i", b, 0)[0] != 9994:
        raise ValueError("The .shp file is damaged (bad header).")
    out = []
    o = 100
    while o + 8 <= len(b):
        length = struct.unpack_from(">i", b, o + 4)[0] * 2
        s = o + 8
        e = min(len(b), s + length)
        o = s + length
        if length < 4:
            out.append(None)
            continue
        t = struct.unpack_from("<i", b, s)[0]
        if t not in _SHP_POLY:
            out.append(None)
            continue
        n_parts, n_pts = struct.unpack_from("<ii", b, s + 36)
        p_start = s + 44
        pt_start = p_start + n_parts * 4
        if pt_start + n_pts * 16 > e:
            out.append(None)
            continue
        starts = list(struct.unpack_from(f"<{n_parts}i", b, p_start)) + [n_pts]
        xy = np.frombuffer(b, dtype="<f8", count=n_pts * 2, offset=pt_start).reshape(-1, 2)
        rings = [_open_ring(xy[starts[k]:starts[k + 1]]) for k in range(n_parts)]
        polys = _organize(rings)
        out.append((polys, bytes(b[s:pt_start + n_pts * 16])) if polys else None)
    return out


def _cpg_encoding(cpg: str, ldid: int) -> str:
    c = re.sub(r"[^A-Z0-9]", "", (cpg or "").strip().upper())
    if c == "UTF8":
        return "utf-8"
    if re.match(r"^(CP)?1252$|^WINDOWS1252$|^ANSI1252$", c):
        return "windows-1252"
    if re.match(r"^(ISO)?88591$", c):
        return "iso-8859-1"
    if re.match(r"^(CP)?(437|850)$", c):
        return "windows-1252"
    if ldid in (0x57, 0x03):
        return "windows-1252"
    return "iso-8859-1"


def _ascii(b: bytes) -> str:
    return b.split(b"\0", 1)[0].decode("latin-1")


def _parse_dbf(b: bytes, cpg: str = ""):
    n, hlen, rlen = struct.unpack_from("<IHH", b, 4)
    enc = _cpg_encoding(cpg, b[29])
    fields = []
    off = 1
    o = 32
    while o + 32 <= hlen and b[o] != 0x0D:
        name = _ascii(b[o:o + 11]).strip()
        ftype, flen, fdec = chr(b[o + 11]), b[o + 16], b[o + 17]
        fields.append((name, ftype, flen, fdec, off))
        off += flen
        o += 32
    single_byte = enc != "utf-8"   # then one decoded character per byte, so fields can be sliced after decoding
    records, deleted = [], []
    for i in range(n):
        base = hlen + i * rlen
        if base + rlen > len(b):
            break
        rec_bytes = b[base:base + rlen]
        deleted.append(rec_bytes[0] == 0x2A)
        text = rec_bytes.decode(enc, errors="replace") if single_byte else None
        rec = {}
        for name, ftype, flen, _dec, foff in fields:
            if ftype in "NF":
                s = rec_bytes[foff:foff + flen].strip(b" \0")
                try:
                    v = float(s) if s and s[:1] != b"*" else None
                    v = None if v is None or not math.isfinite(v) else plain_number(v)
                except ValueError:
                    v = None
            elif ftype == "D":
                s = _ascii(rec_bytes[foff:foff + flen]).strip()
                v = f"{s[:4]}-{s[4:6]}-{s[6:8]}" if len(s) == 8 and s.isdigit() and s != "00000000" else None
            elif ftype == "L":
                s = _ascii(rec_bytes[foff:foff + flen]).strip().upper()
                v = "True" if s and s in "TY" else "False" if s and s in "FN" else None
            else:
                raw = text[foff:foff + flen] if text is not None else \
                    rec_bytes[foff:foff + flen].decode(enc, errors="replace")
                v = raw.rstrip("\0").strip() or None
            rec[name] = v
        records.append(rec)
    return [f[0] for f in fields], records, deleted


def _crs_or_none(text: str | None):
    """A CRS from a .prj or definition; None when there is none or pyproj can't read it.
    `crs.resolve_crs` explains which, using the text kept on the layer."""
    if not text:
        return None
    try:
        return CRS.from_user_input(text)
    except Exception:  # pyproj raises CRSError, plus others for garbage input
        return None


def _shapefile_source(name: str, files: dict) -> Source:
    def open_() -> Layer:
        if "dbf" not in files:
            raise ValueError(f"{name}.shp has no .dbf beside it. Include the .dbf (and .prj) with the .shp.")
        shapes = _parse_shp(files["shp"])
        cpg = files["cpg"].decode("utf-8", errors="replace") if "cpg" in files else ""
        columns, recs, deleted = _parse_dbf(files["dbf"], cpg)
        geoms, raw, records = [], [], []
        for i, rec in enumerate(recs):
            if deleted[i]:
                continue
            s = shapes[i] if i < len(shapes) else None
            g = _to_geom(s[0]) if s else None
            geoms.append(g)
            raw.append(s[1] if g is not None else None)
            records.append(rec)
        wkt = files["prj"].decode("utf-8", errors="replace").strip() if "prj" in files else ""
        return _layer(name, columns, geoms, raw, records, crs_text=wkt or None)
    return Source(name=name, kind="Shapefile", open=open_)


# ------------------------------------------------------------------ GeoPackage
def _wkb_polys(b: bytes, o0: int):
    """WKB (ISO, EWKB or with Z/M) -> list of [[outer, holes...], ...] or None."""
    o = o0

    def geom():
        nonlocal o
        le = b[o] == 1
        o += 1
        fmt = "<" if le else ">"
        t = struct.unpack_from(fmt + "I", b, o)[0]
        o += 4
        base, has_z, has_m = t & 0xFFFF, bool(t & 0x80000000), bool(t & 0x40000000)
        if t & 0x20000000:
            o += 4                                  # EWKB SRID
        th, base = divmod(base, 1000)
        has_z = has_z or th in (1, 3)
        has_m = has_m or th in (2, 3)
        dim = 2 + has_z + has_m

        def rd():
            nonlocal o
            v = struct.unpack_from(fmt + "I", b, o)[0]
            o += 4
            return v

        def ring():
            nonlocal o
            n = rd()
            vals = struct.unpack_from(f"{fmt}{n * dim}d", b, o)
            o += 8 * dim * n
            return _open_ring([[vals[i * dim], vals[i * dim + 1]] for i in range(n)])

        if base == 3:
            rs = [ring() for _ in range(rd())]
            return "poly", ([[r for r in rs if len(r) >= 3]] if rs and len(rs[0]) >= 3 else [])
        if base == 6:
            ps = []
            for _ in range(rd()):
                kind, sub = geom()
                if kind == "poly":
                    ps += sub
            return "poly", ps
        return "other", None

    kind, polys = geom()
    return polys if kind == "poly" and polys else None


def _gpkg_geom(blob):
    if not isinstance(blob, (bytes, bytearray)) or len(blob) < 8 or blob[0] != 0x47 or blob[1] != 0x50:
        return None
    flags = blob[3]
    if flags & 0x10:
        return None                                 # empty geometry
    env = [0, 32, 48, 48, 64][(flags >> 1) & 7] if ((flags >> 1) & 7) < 5 else 0
    start = 8 + env
    polys = _wkb_polys(blob, start)
    return (polys, bytes(blob[start:])) if polys else None


def _q(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _geopackage_sources(data: bytes) -> list[Source]:
    fd, path = tempfile.mkstemp(suffix=".gpkg")
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    db = sqlite3.connect(path)
    try:
        tables = db.execute(
            "SELECT c.table_name, g.column_name, g.geometry_type_name, c.srs_id FROM gpkg_contents c "
            "JOIN gpkg_geometry_columns g ON g.table_name = c.table_name WHERE c.data_type = 'features'").fetchall()
    except sqlite3.Error:
        raise ValueError("This .gpkg file has no GeoPackage feature tables.") from None

    def source(table: str, gcol: str, srs_id: int) -> Source:
        def open_() -> Layer:
            info = db.execute(f"PRAGMA table_info({_q(table)})").fetchall()
            pk = [c[1] for c in info if c[5] and str(c[2]).upper().startswith("INT")]
            cols = [(c[1], str(c[2]).upper()) for c in info
                    if c[1] != gcol and not (len(pk) == 1 and c[1] == pk[0])]
            srs = db.execute("SELECT organization, organization_coordsys_id, definition FROM gpkg_spatial_ref_sys "
                             "WHERE srs_id = ?", (srs_id,)).fetchone()
            crs_text = None
            if srs and srs_id and srs_id > 0:
                if str(srs[0]).upper() == "EPSG":
                    crs_text = f"EPSG:{srs[1]}"
                elif srs[2] and srs[2] != "undefined":
                    crs_text = srs[2]
            sel = ", ".join(_q(c) for c, _ in cols) or "NULL"
            geoms, raw, records = [], [], []
            for row in db.execute(f"SELECT {_q(gcol)}, {sel} FROM {_q(table)}"):
                g = _gpkg_geom(row[0])
                geom = _to_geom(g[0]) if g else None
                geoms.append(geom)
                raw.append(g[1] if geom is not None else None)
                rec = {}
                for k, (c, ctype) in enumerate(cols):
                    v = row[k + 1]
                    if isinstance(v, (bytes, bytearray)):
                        v = None
                    elif isinstance(v, str):
                        v = _plain_str(v)
                        if v and ctype.startswith("DATE"):
                            v = v[:10]
                    elif isinstance(v, float):
                        v = plain_number(v) if math.isfinite(v) else None
                    rec[c] = v
                records.append(rec)
            return _layer(table, [c for c, _ in cols], geoms, raw, records, crs_text=crs_text)
        return Source(name=table, kind="GeoPackage", open=open_)

    return [source(t, g, s) for t, g, gt, s in tables if "POLYGON" in str(gt).upper()]


# ------------------------------------------------------------------ GeoJSON
def _geojson_source(name: str, text: str) -> Source:
    def open_() -> Layer:
        try:
            gj = json.loads(text)
        except ValueError as e:
            raise ValueError(f"{name} isn't valid GeoJSON ({e}).") from None
        t = gj.get("type") if isinstance(gj, dict) else None
        feats = (gj.get("features") or []) if t == "FeatureCollection" else [gj] if t == "Feature" else []
        columns: list[str] = []
        for f in feats:
            for k in (f.get("properties") or {}):
                if k not in columns:
                    columns.append(k)

        def poly(c):
            return [r for r in (_open_ring([[float(p[0]), float(p[1])] for p in (r or [])]) for r in (c or []))
                    if len(r) >= 3]

        geoms, raw, records = [], [], []
        for f in feats:
            g = f.get("geometry") or {}
            polys = None
            if g.get("type") == "Polygon":
                p = poly(g.get("coordinates"))
                polys = [p] if p else None
            elif g.get("type") == "MultiPolygon":
                ps = [p for p in (poly(c) for c in (g.get("coordinates") or [])) if p]
                polys = ps or None
            geom = _to_geom(polys) if polys else None
            geoms.append(geom)
            raw.append(json.dumps(g.get("coordinates"), separators=(",", ":")).encode() if geom is not None else None)
            pr = f.get("properties") or {}
            rec = {}
            for c in columns:
                v = pr.get(c)
                if isinstance(v, str):
                    v = _plain_str(v)
                elif isinstance(v, bool):
                    v = "True" if v else "False"
                elif isinstance(v, float):
                    v = plain_number(v) if math.isfinite(v) else None
                elif isinstance(v, (dict, list)):
                    v = json.dumps(v, separators=(",", ":"))
                rec[c] = v
            records.append(rec)
        crs_text = "EPSG:4326"
        nm = ((gj.get("crs") or {}).get("properties") or {}).get("name") if isinstance(gj, dict) else None
        if nm:
            m = re.search(r"EPSG:{1,2}(\d+)", nm, re.I)
            if m:
                crs_text = f"EPSG:{m.group(1)}"
            elif re.search(r"CRS84", nm, re.I):
                crs_text = "EPSG:4326"
        return _layer(name, columns, geoms, raw, records, crs_text=crs_text)
    return Source(name=name, kind="GeoJSON", open=open_)


# ------------------------------------------------------------------ shared
def _layer(name, columns, geoms, raw, records, crs_text) -> Layer:
    return Layer(path=name, name=name, crs=_crs_or_none(crs_text), columns=columns, geoms=geoms, wkb=raw,
                 records=records, skipped=sum(g is None for g in geoms), layers_in_file=[name],
                 crs_text=crs_text)


def open_files(files: list[tuple[str, bytes]]) -> list[Source]:
    """`files`: (name, bytes) pairs as picked or dropped. Returns every polygon layer found."""
    entries: list[tuple[str, bytes]] = []
    for name, data in files:
        if _ext(name) == "zip":
            try:
                z = zipfile.ZipFile(io.BytesIO(data))
                names = z.namelist()
            except (zipfile.BadZipFile, OSError) as e:
                raise ValueError(f"{name} couldn't be unzipped ({e}).") from None
            inside = [n for n in names if not re.search(r"(^|/)__MACOSX/", n) and _WANTED.search(n)]
            if not inside:
                if any(re.search(r"\.gdb/", n, re.I) for n in names):
                    raise ValueError(f"{name} holds a file geodatabase (.gdb). This page can't read those yet: "
                                     + FGDB_HINT[0].lower() + FGDB_HINT[1:])
                raise ValueError(f"{name} has no shapefile, GeoPackage or GeoJSON inside.")
            entries += [(n, z.read(n)) for n in inside]
        else:
            entries.append((name, data))

    sources: list[Source] = []
    shp: dict[str, dict] = {}
    for name, data in entries:
        x = _ext(name)
        if x in ("shp", "dbf", "prj", "cpg"):
            key = re.sub(r"\.[^.]+$", "", name).lower()
            shp.setdefault(key, {"name": _stem(name)})[x] = data
        elif x == "gpkg":
            sources += _geopackage_sources(data)
        elif x in ("geojson", "json"):
            sources.append(_geojson_source(_stem(name), data.decode("utf-8", errors="replace")))
        elif x in ("gdb", "gdbtable"):
            raise ValueError("File geodatabases (.gdb) can't be read here yet. " + FGDB_HINT)
    for s in shp.values():
        b = s.get("shp")
        if b and len(b) >= 36 and struct.unpack_from("<i", b, 32)[0] in _SHP_POLY:
            sources.append(_shapefile_source(s["name"], s))
    if not sources:
        if any("dbf" in s and "shp" not in s for s in shp.values()):
            raise ValueError("Only the .dbf came through. Pick the .shp, .dbf and .prj together, "
                             "or the whole zipped shapefile.")
        raise ValueError("No polygon layer was found. Use a zipped shapefile, a GeoPackage (.gpkg) "
                         "or GeoJSON with parcel polygons.")
    return sources


__all__ = ["Source", "open_files", "plain_number"]
