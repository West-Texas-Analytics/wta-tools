"""`wta-stacks`: build the parcel stacks 3D page from any county parcel file.

    wta-stacks info  PARCELS             show layers, columns and which ones were recognised
    wta-stacks build PARCELS -o OUT.html build the page (and optionally a CSV of every stacked row)
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .build import build, stacks_csv
from .detect import DEFAULT_DETECT_CRS
from .fields import CANDIDATES, map_fields
from .load import list_polygon_layers, read_layer
from .viewer import render_html


def _overrides(pairs: list[str]) -> dict[str, str]:
    out = {}
    for p in pairs:
        role, sep, col = p.partition("=")
        if not sep or not role or not col:
            raise ValueError(f"--field takes ROLE=COLUMN (e.g. owner=OWNER1), not '{p}'.")
        out[role.strip()] = col.strip()
    return out


def cmd_info(a) -> int:
    print(f"Polygon layers: {', '.join(list_polygon_layers(a.parcels)) or '(none)'}")
    layer = read_layer(a.parcels, a.layer, a.source_crs)
    print(f"Layer: {layer.name} · {len(layer.geoms):,} features · CRS {layer.crs.to_string()}")
    if layer.skipped:
        print(f"Rows with no usable polygon: {layer.skipped:,}")
    roles = map_fields(layer.columns, _overrides(a.field))
    print("Recognised columns:")
    for role in CANDIDATES:
        print(f"  {role:<13} {roles.get(role, '— not found (map it with --field ' + role + '=COLUMN)')}")
    print(f"All columns: {', '.join(layer.columns)}")
    return 0


def cmd_build(a) -> int:
    layer = read_layer(a.parcels, a.layer, a.source_crs)
    title = a.title or f"{Path(a.parcels).stem} parcel stacks"
    res = build(layer, title=title, source=a.source or f"{layer.path} · layer {layer.name}",
                overrides=_overrides(a.field), color_columns=a.color, detect_crs=a.detect_crs, likely_causes=True)
    out = Path(a.out)
    out.write_text(render_html(res.view), encoding="utf-8")
    v = res.view
    print(f"{v['parcels']:,} parcels · {len(v['stacks']):,} stacks · {len(res.stack_rows):,} rows in stacks")
    print(f"Wrote {out} ({out.stat().st_size / 1e6:.1f} MB)")
    if v["missing_roles"]:
        print(f"Not found in this file: {', '.join(v['missing_roles'])}")
    if v["empty_roles"]:
        print(f"Empty on every row: {', '.join(v['empty_roles'])}")
    if a.csv:
        Path(a.csv).write_text(stacks_csv(res.stack_rows), encoding="utf-8")
        print(f"Wrote {a.csv}")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="wta-stacks", description="Find stacked (same-shape) parcels and build a 3D page.")
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("parcels", help="parcel file: .shp, .zip (zipped shapefile), .gpkg, .gdb folder or .geojson")
        sp.add_argument("--layer", help="layer name, when the file has more than one polygon layer")
        sp.add_argument("--source-crs", help="CRS for a file with none (e.g. a shapefile missing its .prj)")
        sp.add_argument("--field", action="append", default=[], metavar="ROLE=COLUMN",
                        help=f"use COLUMN for ROLE; roles: {', '.join(CANDIDATES)}")

    i = sub.add_parser("info", help="show what the tool sees in a file")
    common(i)
    i.set_defaults(fn=cmd_info)

    b = sub.add_parser("build", help="build the 3D page")
    common(b)
    b.add_argument("-o", "--out", required=True, help="HTML file to write")
    b.add_argument("--title", help="page title, e.g. 'Example County parcel stacks'")
    b.add_argument("--source", help="where the file came from, shown under the title")
    b.add_argument("--color", action="append", default=[], metavar="COLUMN", help="extra column to color by")
    b.add_argument("--csv", help="also write every stacked row to this CSV file")
    b.add_argument("--detect-crs", default=DEFAULT_DETECT_CRS,
                   help=f"projected CRS for comparing shapes (default {DEFAULT_DETECT_CRS}, Texas Central)")
    b.set_defaults(fn=cmd_build)

    a = p.parse_args(argv)
    try:
        return a.fn(a)
    except (ValueError, OSError) as e:
        print(f"wta-stacks: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
