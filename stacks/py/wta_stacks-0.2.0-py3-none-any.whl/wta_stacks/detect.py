"""Find stacks: two or more rows whose polygons are the same shape.

The rule (agreed in the scoping plan): work in a projected CRS in feet
(EPSG:2277, Texas Central, by default), round every vertex to 0.01 ft, drop
repeated points, turn every exterior ring counter-clockwise and every hole
clockwise, start each ring at its lowest vertex, sort the parts, then compare.
A stack is "exact" when every row's stored geometry bytes are identical too.
"""

from __future__ import annotations

import hashlib
from collections import defaultdict
from dataclasses import dataclass

import numpy as np
import shapely
from pyproj import CRS, Transformer

DEFAULT_DETECT_CRS = "EPSG:2277"
PRECISION_FT = 0.01


def feet_per_unit(crs: CRS) -> float:
    """How many feet one unit of a projected CRS is (US survey foot, foot or metre)."""
    unit = (crs.axis_info[0].unit_name or "").lower() if crs.axis_info else ""
    if "foot" in unit or unit in ("foot_us", "us_survey_foot"):
        return 1.0  # US survey and international feet differ by 2 ppm; treated as the same
    if "metre" in unit or "meter" in unit:
        return 1 / 0.3048
    raise ValueError(f"The detection CRS must be projected in feet or metres; {crs.name} uses '{unit}'.")


def to_feet(geoms: list, source: CRS, target: str = DEFAULT_DETECT_CRS) -> list:
    """Reproject geometries to `target` and scale them to feet. None stays None."""
    dst = CRS.from_user_input(target)
    if not dst.is_projected:
        raise ValueError(f"The detection CRS must be projected; {dst.name} isn't.")
    k = feet_per_unit(dst)
    tr = Transformer.from_crs(source, dst, always_xy=True)

    def fn(xy: np.ndarray) -> np.ndarray:
        x, y = tr.transform(xy[:, 0], xy[:, 1])
        return np.column_stack([np.asarray(x) * k, np.asarray(y) * k])

    idx = [i for i, g in enumerate(geoms) if g is not None]
    out: list = [None] * len(geoms)
    if idx:  # one transform call for every vertex in the layer: much faster than one per shape
        moved = shapely.transform(np.array([geoms[i] for i in idx], dtype=object), fn)
        for i, g in zip(idx, moved):
            out[i] = g
    return out


def explode(geoms: list) -> list[list[list[np.ndarray]]]:
    """Each (Multi)Polygon -> its parts -> its rings (exterior first), as closed coordinate arrays.

    Done for the whole list at once with shapely's array functions, which is several
    times faster than walking each shape's Python objects (it matters in the browser).
    None or empty shapes give [].
    """
    out: list[list[list[np.ndarray]]] = [[] for _ in geoms]
    idx = [i for i, g in enumerate(geoms) if g is not None and not g.is_empty]
    if not idx:
        return out
    parts, part_geom = shapely.get_parts(np.array([geoms[i] for i in idx], dtype=object), return_index=True)
    rings, ring_part = shapely.get_rings(parts, return_index=True)
    coords, coord_ring = shapely.get_coordinates(rings, return_index=True)
    cuts = np.flatnonzero(np.diff(coord_ring)) + 1
    starts = np.concatenate([[0], cuts])
    ring_ids = coord_ring[starts] if len(coords) else np.array([], dtype=int)
    arrays = dict(zip(ring_ids.tolist(), np.split(coords, cuts)))
    part_rings: list[list[np.ndarray]] = [[] for _ in range(len(parts))]
    for r, p in enumerate(ring_part.tolist()):
        if r in arrays:
            part_rings[p].append(arrays[r])
    for p, g in enumerate(part_geom.tolist()):
        if part_rings[p]:
            out[idx[g]].append(part_rings[p])
    return out


def _ring(pts: list, ccw: bool) -> tuple:
    """`pts`: one closed ring's vertices, already rounded to 0.01 ft."""
    pts = [tuple(p) for p in pts[:-1]]
    out = [pts[0]] if pts else []
    for p in pts[1:]:
        if p != out[-1]:
            out.append(p)
    while len(out) > 1 and out[-1] == out[0]:
        out.pop()
    if len(out) < 3:
        return tuple(out)
    area2 = sum(out[i][0] * out[(i + 1) % len(out)][1] - out[(i + 1) % len(out)][0] * out[i][1]
                for i in range(len(out)))
    if (area2 > 0) != ccw:
        out.reverse()
    k = out.index(min(out))
    return tuple(out[k:] + out[:k])


def shape_keys(geoms_ft: list) -> list[str | None]:
    """A hash per polygon, equal for two polygons that are the same shape under the rule above."""
    keys: list[str | None] = []
    for g, parts_rings in zip(geoms_ft, explode(geoms_ft)):
        if g is None:
            keys.append(None)
            continue
        parts = []
        for rings in parts_rings:
            rounded = [np.round(r, 2).tolist() for r in rings]
            ext = _ring(rounded[0], ccw=True)
            holes = tuple(sorted(_ring(h, ccw=False) for h in rounded[1:]))
            parts.append((ext, holes))
        parts.sort()
        keys.append(hashlib.sha1(repr(parts).encode()).hexdigest())
    return keys


def shape_key(geom_ft) -> str:
    """The hash for one polygon (see `shape_keys`)."""
    return shape_keys([geom_ft])[0]


@dataclass
class Stack:
    rows: list[int]   # feature indexes, in file order
    exact: bool       # stored geometry bytes identical on every row


def find_stacks(geoms_ft: list, raw_wkb: list | None = None) -> list[Stack]:
    """Group features by shape; return groups of 2+ rows, tallest first."""
    groups: dict[str, list[int]] = defaultdict(list)
    for i, k in enumerate(shape_keys(geoms_ft)):
        if k is not None:
            groups[k].append(i)
    stacks = []
    for rows in groups.values():
        if len(rows) < 2:
            continue
        exact = raw_wkb is not None and len({raw_wkb[i] for i in rows}) == 1
        stacks.append(Stack(rows=rows, exact=exact))
    stacks.sort(key=lambda s: (-len(s.rows), s.rows[0]))
    return stacks
