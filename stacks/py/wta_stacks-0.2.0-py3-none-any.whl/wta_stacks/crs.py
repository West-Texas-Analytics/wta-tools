"""Coordinate systems Parcel Stacks offers by name, and turning what a file says
about its coordinates into one pyproj can use."""

from __future__ import annotations

import re

from pyproj import CRS

from .detect import DEFAULT_DETECT_CRS

# Offered in the "coordinate system" pickers, in this order. `zone`: a Texas State
# Plane zone in US feet, which shapes can be compared in.
KNOWN: dict[str, dict] = {
    "EPSG:4326": {"name": "WGS 84 (latitude/longitude)"},
    "EPSG:4269": {"name": "NAD83 (latitude/longitude)"},
    "EPSG:2275": {"name": "NAD83 / Texas North (US ft)", "zone": True},
    "EPSG:2276": {"name": "NAD83 / Texas North Central (US ft)", "zone": True},
    "EPSG:2277": {"name": "NAD83 / Texas Central (US ft)", "zone": True},
    "EPSG:2278": {"name": "NAD83 / Texas South Central (US ft)", "zone": True},
    "EPSG:2279": {"name": "NAD83 / Texas South (US ft)", "zone": True},
    "EPSG:26913": {"name": "NAD83 / UTM zone 13N"},
    "EPSG:26914": {"name": "NAD83 / UTM zone 14N"},
    "EPSG:26915": {"name": "NAD83 / UTM zone 15N"},
    "EPSG:32613": {"name": "WGS 84 / UTM zone 13N"},
    "EPSG:32614": {"name": "WGS 84 / UTM zone 14N"},
    "EPSG:32615": {"name": "WGS 84 / UTM zone 15N"},
    "EPSG:3081": {"name": "NAD83 / Texas State Mapping System"},
    "EPSG:3083": {"name": "NAD83 / Texas Centric Albers Equal Area"},
    "EPSG:3857": {"name": "Web Mercator"},
}
ZONES = [k for k, v in KNOWN.items() if v.get("zone")]
DEFAULT_DETECT = DEFAULT_DETECT_CRS

_EXPORT = "Export it as latitude/longitude (EPSG:4326) or Texas State Plane and try again."


def resolve_crs(text: str | None) -> dict | None:
    """What a file says about its CRS (an "EPSG:n" code or WKT) -> {code, name, def}.

    `def` is what to hand back to `build` as the source CRS. Returns None when the
    file says nothing; raises ValueError (worded for the page) when it can't be read.
    """
    if not text:
        return None
    text = text.strip()
    m = re.fullmatch(r"EPSG:(\d+)", text, re.I)
    if m:
        code = f"EPSG:{m.group(1)}"
        if code in KNOWN:
            return {"code": code, "name": KNOWN[code]["name"], "def": code}
        try:
            return {"code": code, "name": CRS.from_user_input(code).name, "def": code}
        except Exception:
            raise ValueError(f"This file uses {code}, which this page doesn't know. {_EXPORT}") from None
    name = (re.match(r'^\s*\w+\s*\[\s*"([^"]+)"', text) or [None, "from the file"])[1]
    try:
        crs = CRS.from_user_input(text)
    except Exception:
        raise ValueError(f"This file's coordinate system ({name}) isn't one this page can read. {_EXPORT}") from None
    epsg = crs.to_epsg(min_confidence=90)
    code = f"EPSG:{epsg}" if epsg else None
    return {"code": code, "name": name, "def": text}
